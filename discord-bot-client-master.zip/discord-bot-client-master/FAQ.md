# FAQ:
<hr>

### Disclaimer:
- This application is for developers only (if you don't know how to use it, dont use it and don't ask for help).
- We do not offer support in any way.
- This application requires a basic understanding of Discord bots and how to use them, again, don't ask for help.

<hr>

# Common Errors:
### most common fixes:
- reload (control + r)
- restart (app & pc)
- reinstall 
- use portable version
## Blank Screen or error message:
- view [Most common fixes](https://github.com/Flam3rboy/discord-bot-client/blob/master/FAQ.md#most-common-fixes)
## Not able to run App:
- view [Most common fixes](https://github.com/Flam3rboy/discord-bot-client/blob/master/FAQ.md#most-common-fixes)
